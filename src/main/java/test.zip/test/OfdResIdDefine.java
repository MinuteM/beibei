package test;

/**
 * OFD资源ID定义
 */
public class OfdResIdDefine {

	public static final long RID_ColorSpace = 1;

	public static final long RID_VarStart = 100;

}
